package sp.senai.br.genero;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etNome;
    TextView tvGenero;
    Button btnAcao;
    RadioGroup rgGenero;
    RadioButton rbMasc, rbFem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etNome = findViewById(R.id.etNome);
        tvGenero = findViewById(R.id.tvGenero);
        btnAcao = findViewById(R.id.btnAcao);
        rgGenero = findViewById(R.id.rgGenero);
        rbFem = findViewById(R.id.rbFem);
        rbMasc = findViewById(R.id.rbMasc);
        //Limpando o textview
        tvGenero.setText(null);
    }
    public void acao (View a){
        if (btnAcao.getText().toString().equalsIgnoreCase("Exibir")) {
            if (!etNome.getText().toString().equalsIgnoreCase("")) {
                btnAcao.setText("Limpar");
                etNome.setEnabled(false);
                rbMasc.setEnabled(false);
                rbFem.setEnabled(false);
                if (rbFem.isChecked()){
                    tvGenero.setText(etNome.getText().toString()+", você é do gênero feminino.");
                } else {
                    tvGenero.setText(etNome.getText().toString()+", você é do gênero masculino.");
                }
            } else {
                Toast.makeText(this,"Necessita preencher o nome",Toast.LENGTH_LONG).show();
            }
        } else {
            btnAcao.setText("Exibir");
            etNome.setEnabled(true);
            rbMasc.setEnabled(true);
            rbFem.setEnabled(true);
            etNome.setText(null);
            etNome.requestFocus();
            tvGenero.setText(null);
        }
    }
}